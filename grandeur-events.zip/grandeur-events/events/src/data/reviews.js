const reviews = [
  {
    id: 1,
    name: "Harshika",
    event: "Wedding Celebration",
    text: "Grandeur Events made our wedding absolutely magical and unforgettable."
  },
  {
    id: 2,
    name: "Rahul",
    event: "Corporate Event",
    text: "The professionalism and luxury arrangements exceeded our expectations."
  },
  {
    id: 3,
    name: "Sneha",
    event: "Birthday Party",
    text: "Beautiful venue, amazing decor, and smooth execution."
  }
];

export default reviews;