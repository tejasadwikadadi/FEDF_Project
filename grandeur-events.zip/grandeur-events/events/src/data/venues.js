const venues = [
  {
    id: 1,
    name: "Royal Palace",
    category: "Luxury Wedding",
    type: "Premium",
    description: "Elegant hall for grand weddings and receptions.",
    price: "₹50,000",
    image: "https://images.unsplash.com/photo-1519167758481-83f550bb49b3"
  },
  {
    id: 2,
    name: "Skyline Banquet",
    category: "Corporate",
    type: "Executive",
    description: "Perfect for conferences and corporate events.",
    price: "₹40,000",
    image: "https://images.unsplash.com/photo-1511578314322-379afb476865"
  },
  {
    id: 3,
    name: "Golden Blossom",
    category: "Birthday Hall",
    type: "Celebration",
    description: "Beautifully designed for birthdays and family events.",
    price: "₹30,000",
    image: "https://images.unsplash.com/photo-1464366400600-7168b8af9bc3"
  }
];

export default venues;