const events = [
  {
    id: 1,
    name: "Weddings",
    description: "Luxury weddings crafted with timeless elegance."
  },
  {
    id: 2,
    name: "Birthdays",
    description: "Celebrate memorable birthdays in style."
  },
  {
    id: 3,
    name: "Corporate",
    description: "Professional setups for meetings and conferences."
  },
  {
    id: 4,
    name: "Reception",
    description: "Beautiful receptions designed for unforgettable evenings."
  }
];

export default events;