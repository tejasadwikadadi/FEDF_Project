const services = [
  {
    id: 1,
    number: "01",
    name: "Premium Catering",
    description: "Curated gourmet menus for unforgettable dining experiences."
  },
  {
    id: 2,
    number: "02",
    name: "Luxury Decoration",
    description: "Elegant floral and theme-based decor tailored to your event."
  },
  {
    id: 3,
    number: "03",
    name: "Photography",
    description: "Capture timeless memories with professional photography."
  },
  {
    id: 4,
    number: "04",
    name: "Entertainment",
    description: "Live music, DJs, and performances for vibrant celebrations."
  }
];

export default services;