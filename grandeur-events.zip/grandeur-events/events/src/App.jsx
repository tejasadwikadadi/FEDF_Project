import { useState } from "react";

import Navbar from "./components/Navbar.jsx";
import Hero from "./components/Hero.jsx";
import StatsBar from "./components/StatsBar.jsx";
import Venues from "./components/Venues.jsx";
import Gallery from "./components/Gallery.jsx";
import EventTypes from "./components/EventTypes.jsx";
import Services from "./components/Services.jsx";
import Booking from "./components/Booking.jsx";
import Testimonials from "./components/Testimonials.jsx";
import Footer from "./components/Footer.jsx";

import AuthModal from "./modals/AuthModal.jsx";
import ProfileModal from "./modals/ProfileModal.jsx";
import VenueModal from "./modals/VenueModal.jsx";
import AdminDashboard from "./modals/AdminDashboard.jsx";

function App() {
  const [authOpen, setAuthOpen] = useState(false);
  const [profileOpen, setProfileOpen] = useState(false);
  const [venueOpen, setVenueOpen] = useState(false);
  const [adminOpen, setAdminOpen] = useState(false);

  const [selectedVenue, setSelectedVenue] = useState(null);

  const openVenue = (venue) => {
    setSelectedVenue(venue);
    setVenueOpen(true);
  };

  return (
    <>
      <Navbar
        openAuth={() => setAuthOpen(true)}
        openProfile={() => setProfileOpen(true)}
        openAdmin={() => setAdminOpen(true)}
      />

      <Hero />
      <StatsBar />
      <Venues openVenue={openVenue} />
      <Gallery />
      <EventTypes />
      <Services />
      <Booking />
      <Testimonials />
      <Footer />

      <AuthModal
        isOpen={authOpen}
        onClose={() => setAuthOpen(false)}
      />

      <ProfileModal
        isOpen={profileOpen}
        onClose={() => setProfileOpen(false)}
      />

      <VenueModal
        isOpen={venueOpen}
        onClose={() => setVenueOpen(false)}
        venue={selectedVenue}
      />

      <AdminDashboard
        isOpen={adminOpen}
        onClose={() => setAdminOpen(false)}
      />
    </>
  );
}

export default App;