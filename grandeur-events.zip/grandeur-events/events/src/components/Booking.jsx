function Booking() {
  return (
    <section id="booking">
      <div className="bk-layout">
        <div className="bk-info">
          <p className="sec-eye">Reserve Your Moment</p>

          <h2 className="sec-title">
            Begin Your <em>Celebration</em>
          </h2>

          <p>
            Secure your preferred venue and date with our seamless
            reservation process. Every celebration begins here.
          </p>

          <div className="bk-contacts">
            <div className="bk-ci">
              <strong>Phone:</strong> +91 98765 43210
            </div>

            <div className="bk-ci">
              <strong>Email:</strong> booking@grandeurevents.com
            </div>

            <div className="bk-ci">
              <strong>Location:</strong> Hyderabad, India
            </div>
          </div>
        </div>

        <div className="wiz">
          <h3 className="wiz-title">Book Your Event</h3>

          <form>
            <div className="fg">
              <label>Name</label>
              <input type="text" placeholder="Enter your name" />
            </div>

            <div className="fg">
              <label>Email</label>
              <input type="email" placeholder="Enter your email" />
            </div>

            <div className="fg2">
              <div className="fg">
                <label>Date</label>
                <input type="date" />
              </div>

              <div className="fg">
                <label>Guests</label>
                <input type="number" placeholder="Guests" />
              </div>
            </div>

            <div className="fg">
              <label>Message</label>
              <textarea placeholder="Tell us about your event"></textarea>
            </div>

            <button className="wbt-next" type="submit">
              Confirm Booking
            </button>
          </form>
        </div>
      </div>
    </section>
  );
}

export default Booking;