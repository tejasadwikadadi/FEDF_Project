import events from "../data/events";

function EventTypes() {
  return (
    <section id="events">
      <div style={{ textAlign: "center", maxWidth: "520px", margin: "0 auto" }}>
        <p className="sec-eye">We Specialise In</p>
        <h2 className="sec-title">
          Curated <em>Event Experiences</em>
        </h2>
      </div>

      <div className="ev-grid">
        {events.map((event) => (
          <div className="ev-item" key={event.id}>
            <div className="ev-icon">✦</div>
            <h3 className="ev-name">{event.name}</h3>
            <p className="ev-desc">{event.description}</p>
          </div>
        ))}
      </div>
    </section>
  );
}

export default EventTypes;