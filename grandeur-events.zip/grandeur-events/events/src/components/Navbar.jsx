function Navbar({ openAuth, openProfile, openAdmin }) {
  return (
    <nav>
      <div className="nav-logo">
        Grand<em>eur</em> Events
      </div>

      <ul className="nav-links">
        <li><a href="#venues">Venues</a></li>
        <li><a href="#services">Services</a></li>
        <li><a href="#events">Event Types</a></li>
        <li><a href="#testimonials">Reviews</a></li>
      </ul>

      <div className="nav-right">
        <button className="btn-nav" onClick={openAuth}>
          Sign In
        </button>

        <button className="btn-profile" onClick={openProfile}>
          Profile
        </button>

        <button className="btn-profile" onClick={openAdmin}>
          Admin
        </button>
      </div>
    </nav>
  );
}

export default Navbar;