function Hero() {
  return (
    <section className="hero">
      <div className="hero-bg"></div>
      <div className="hero-lines"></div>

      <div className="hero-content">
        <p className="eyebrow">
          Est. 2008 · Hyderabad's Premier Event House
        </p>

        <h1 className="hero-title">
          Craft <em>Unforgettable</em>
          <br />
          Celebrations
        </h1>

        <p className="hero-sub">
          From intimate banquets to grand galas — we design experiences
          that linger long after the last toast.
        </p>

        <div className="hero-btns">
          <button
            className="btn-gold"
            onClick={() =>
              document.getElementById("booking")?.scrollIntoView({
                behavior: "smooth",
              })
            }
          >
            Reserve Your Date
          </button>

          <button
            className="btn-ghost"
            onClick={() =>
              document.getElementById("venues")?.scrollIntoView({
                behavior: "smooth",
              })
            }
          >
            Explore Venues
          </button>
        </div>
      </div>

      <div className="hero-scroll">Discover</div>
    </section>
  );
}

export default Hero;