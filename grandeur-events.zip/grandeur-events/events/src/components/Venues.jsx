import venues from "../data/venues";

function Venues({ openVenue }) {
  return (
    <section id="venues">
      <div className="venues-hdr">
        <div>
          <p className="sec-eye">Our Spaces</p>
          <h2 className="sec-title">
            Venues Crafted
            <br />
            for <em>Every Occasion</em>
          </h2>
        </div>

        <button
  className="btn-sm"
  onClick={() => openVenue(venue)}
>
  View
</button>
      </div>

      <div className="venues-grid">
        {venues.map((venue) => (
          <div className="vc" key={venue.id}>
            <div className="vc-img">
              <img src={venue.image} alt={venue.name} />
              <div className="vc-badge">{venue.type}</div>
            </div>

            <div className="vc-body">
              <p className="vc-type">{venue.category}</p>
              <h3 className="vc-name">{venue.name}</h3>
              <p className="vc-desc">{venue.description}</p>

              <div className="vc-foot">
                <div className="vc-price">
                  {venue.price} <span>/ event</span>
                </div>

                <button className="btn-sm">View</button>
              </div>
            </div>
          </div>
        ))}
      </div>
    </section>
  );
}

export default Venues;