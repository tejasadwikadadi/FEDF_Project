function Footer() {
  return (
    <footer>
      <div className="ft-grid">
        <div>
          <span className="ft-logo">
            Grand<em>eur</em> Events
          </span>

          <p className="ft-tag">
            Crafting luxurious celebrations and unforgettable moments
            with elegance, precision, and passion.
          </p>
        </div>

        <div>
          <h4 className="ft-col-title">Explore</h4>
          <ul className="ft-links">
            <li><a href="#venues">Venues</a></li>
            <li><a href="#services">Services</a></li>
            <li><a href="#events">Events</a></li>
          </ul>
        </div>

        <div>
          <h4 className="ft-col-title">Contact</h4>
          <ul className="ft-links">
            <li><a href="#">Hyderabad</a></li>
            <li><a href="#">+91 98765 43210</a></li>
            <li><a href="#">booking@grandeurevents.com</a></li>
          </ul>
        </div>

        <div>
          <h4 className="ft-col-title">Follow</h4>
          <ul className="ft-links">
            <li><a href="#">Instagram</a></li>
            <li><a href="#">Facebook</a></li>
            <li><a href="#">Twitter</a></li>
          </ul>
        </div>
      </div>

      <div className="ft-bottom">
        <p className="ft-copy">
          © 2026 Grandeur Events. All rights reserved.
        </p>
      </div>
    </footer>
  );
}

export default Footer;