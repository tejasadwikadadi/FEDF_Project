import services from "../data/services";

function Services() {
  return (
    <section id="services">
      <div className="srv-layout">
        <div>
          <p className="sec-eye">Our Signature</p>
          <h2 className="sec-title">
            Bespoke <em>Luxury Services</em>
          </h2>
        </div>

        <div className="srv-list">
          {services.map((service) => (
            <div className="srv-item" key={service.id}>
              <div className="srv-num">{service.number}</div>
              <h3 className="srv-name">{service.name}</h3>
              <p className="srv-desc">{service.description}</p>
              <span className="srv-arrow">›</span>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

export default Services;