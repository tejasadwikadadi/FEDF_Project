function StatsBar() {
  const stats = [
    { number: "1,200+", label: "Events Hosted" },
    { number: "8", label: "Unique Venues" },
    { number: "98%", label: "Client Satisfaction" },
    { number: "16+", label: "Years of Excellence" },
  ];

  return (
    <div className="stats-bar">
      {stats.map((stat, index) => (
        <div className="stat" key={index}>
          <div className="stat-n">{stat.number}</div>
          <div className="stat-l">{stat.label}</div>
        </div>
      ))}
    </div>
  );
}

export default StatsBar;