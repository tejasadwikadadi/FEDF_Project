import reviews from "../data/reviews";

function Testimonials() {
  return (
    <section id="testimonials">
      <div style={{ textAlign: "center", maxWidth: "520px", margin: "0 auto" }}>
        <p className="sec-eye">Client Stories</p>

        <h2 className="sec-title">
          What Our <em>Clients Say</em>
        </h2>
      </div>

      <div className="t-grid">
        {reviews.map((review) => (
          <div className="t-card" key={review.id}>
            <div className="t-q">“</div>

            <p className="t-text">{review.text}</p>

            <div className="t-auth">
              <div className="t-av">{review.name[0]}</div>

              <div>
                <div className="t-name">{review.name}</div>
                <div className="t-ev">{review.event}</div>
              </div>
            </div>
          </div>
        ))}
      </div>
    </section>
  );
}

export default Testimonials;