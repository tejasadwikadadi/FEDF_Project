function Gallery() {
  const galleryItems = [
    "Luxury Weddings",
    "Corporate Excellence",
    "Birthday Celebrations",
    "Grand Receptions"
  ];

  return (
    <div className="gstrip">
      {galleryItems.map((item, index) => (
        <div className="gi" key={index}>
          <div className="gi-ov"></div>
          <div className="gi-lbl">{item}</div>
        </div>
      ))}
    </div>
  );
}

export default Gallery;