function AuthModal({ isOpen, onClose }) {
  if (!isOpen) return null;

  return (
    <div className="auth-modal open">
      <div className="auth-box">
        <button className="auth-close" onClick={onClose}>
          ✕
        </button>

        <div className="auth-logo">
          Grand<em>eur</em> Events
        </div>

        <p className="auth-tag">
          Welcome back. Sign in to continue.
        </p>

        <div className="auth-panel on">
          <div className="afg">
            <label>Email</label>
            <input
              type="email"
              placeholder="Enter your email"
            />
          </div>

          <div className="afg">
            <label>Password</label>
            <input
              type="password"
              placeholder="Enter your password"
            />
          </div>

          <button className="auth-submit">
            Sign In
          </button>

          <div className="auth-switch">
            New here? <a href="/">Create account</a>
          </div>
        </div>
      </div>
    </div>
  );
}

export default AuthModal;