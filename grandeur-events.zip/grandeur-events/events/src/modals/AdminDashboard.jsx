function AdminDashboard({ isOpen, onClose }) {
  if (!isOpen) return null;

  return (
    <div className="adm-dash open">
      <div className="adm-topbar">
        <div className="adm-brand">
          <div className="adm-brand-name">
            Grand<em>eur</em> Events
          </div>
          <span className="adm-badge">Admin</span>
        </div>

        <button className="adm-signout" onClick={onClose}>
          Close
        </button>
      </div>

      <div className="adm-content">
        <h3 className="adm-sec-title">Dashboard Overview</h3>

        <div className="adm-kpis">
          <div className="adm-kpi">
            <div className="adm-kpi-n">120</div>
            <div className="adm-kpi-l">Bookings</div>
          </div>

          <div className="adm-kpi">
            <div className="adm-kpi-n">80</div>
            <div className="adm-kpi-l">Users</div>
          </div>

          <div className="adm-kpi">
            <div className="adm-kpi-n">₹8L</div>
            <div className="adm-kpi-l">Revenue</div>
          </div>

          <div className="adm-kpi">
            <div className="adm-kpi-n">8</div>
            <div className="adm-kpi-l">Venues</div>
          </div>
        </div>

        <div className="adm-users-grid">
          <div className="adm-user-card">
            <h4>Recent Bookings</h4>
            <p>Royal Palace - Wedding</p>
          </div>

          <div className="adm-user-card">
            <h4>Upcoming Events</h4>
            <p>Skyline Banquet - Corporate</p>
          </div>

          <div className="adm-user-card">
            <h4>Pending Requests</h4>
            <p>Golden Blossom - Birthday</p>
          </div>
        </div>
      </div>
    </div>
  );
}

export default AdminDashboard;