function VenueModal({ isOpen, onClose, venue }) {
  if (!isOpen || !venue) return null;

  return (
    <div className="vm-backdrop open">
      <div className="vm-inner">
        <div className="vm-topbar">
          <div className="vm-bc">
            Venue <span>/ Details</span>
          </div>

          <button className="vm-close" onClick={onClose}>
            Close
          </button>
        </div>

        <div className="vm-content">
          <div>
            <div className="vm-tag">{venue.type}</div>

            <h2 className="vm-title">
              {venue.name} <em>Hall</em>
            </h2>

            <p className="vm-sub">{venue.description}</p>

            <div className="vm-stats">
              <div className="vm-stat">
                <div className="vm-stat-n">500+</div>
                <div className="vm-stat-l">Capacity</div>
              </div>

              <div className="vm-stat">
                <div className="vm-stat-n">4.9</div>
                <div className="vm-stat-l">Rating</div>
              </div>

              <div className="vm-stat">
                <div className="vm-stat-n">10+</div>
                <div className="vm-stat-l">Years</div>
              </div>

              <div className="vm-stat">
                <div className="vm-stat-n">24/7</div>
                <div className="vm-stat-l">Support</div>
              </div>
            </div>
          </div>

          <div className="pc">
            <div className="pc-eye">Starting From</div>

            <div className="pc-main">{venue.price}</div>

            <div className="pc-note">Per Event</div>

            <button className="pc-book">
              Reserve Now
            </button>

            <button className="pc-enquire">
              Enquire
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

export default VenueModal;