function ProfileModal({ isOpen, onClose }) {
  if (!isOpen) return null;

  return (
    <div className="prof-modal open">
      <div className="prof-inner">
        <div className="prof-topbar">
          <div className="prof-user">
            <div className="prof-av">H</div>

            <div>
              <div className="prof-name">Harshika</div>
              <div className="prof-email">user@gmail.com</div>
            </div>
          </div>

          <button className="prof-close" onClick={onClose}>
            Close
          </button>
        </div>

        <div className="prof-content">
          <h3 className="prof-sec-title">Profile Summary</h3>

          <div className="prof-summary">
            <div className="prof-sc">
              <div>
                <div className="prof-sc-n">12</div>
                <div className="prof-sc-l">Bookings</div>
              </div>
            </div>

            <div className="prof-sc">
              <div>
                <div className="prof-sc-n">4</div>
                <div className="prof-sc-l">Upcoming Events</div>
              </div>
            </div>

            <div className="prof-sc">
              <div>
                <div className="prof-sc-n">₹2L</div>
                <div className="prof-sc-l">Spent</div>
              </div>
            </div>
          </div>

          <div className="prof-info-grid">
            <div className="prof-ii">
              <div className="prof-ii-lbl">Full Name</div>
              <div className="prof-ii-val">Harshika</div>
            </div>

            <div className="prof-ii">
              <div className="prof-ii-lbl">Email</div>
              <div className="prof-ii-val">user@gmail.com</div>
            </div>
          </div>

          <button className="logout-btn">Logout</button>
        </div>
      </div>
    </div>
  );
}

export default ProfileModal;